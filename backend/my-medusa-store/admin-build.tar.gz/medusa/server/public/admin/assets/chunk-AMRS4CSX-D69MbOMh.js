var r="@medusajs/loyalty-plugin",t=a=>a==null?void 0:a.find(e=>e.name===r);export{t as g};
