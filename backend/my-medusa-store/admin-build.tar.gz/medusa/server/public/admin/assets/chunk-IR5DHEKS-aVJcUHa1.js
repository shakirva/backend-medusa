var o=t=>{const[a,p,e]=t.split("_");return p.split("-").map(r=>r.charAt(0).toUpperCase()+r.slice(1)).join(" ")+(e?` (${e.toUpperCase()})`:"")};export{o as f};
