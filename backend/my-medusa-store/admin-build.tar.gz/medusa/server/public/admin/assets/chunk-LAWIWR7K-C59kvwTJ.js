import{aN as i}from"./index-BaXyCziu.js";var a=i("product","*categories,*shipping_profile,-variants");export{a as P};
