var l=t=>t.quantity-t.detail.fulfilled_quantity;export{l as g};
