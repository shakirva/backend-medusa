var o=(P=>(P.PRODUCT="product",P.PRODUCT_TYPE="product_type",P.SHIPPING_OPTION="shipping_option",P))(o||{});export{o as T};
